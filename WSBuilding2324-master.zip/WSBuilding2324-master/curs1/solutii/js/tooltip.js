
        $(document).ready(function () {
            $('[data-bs-toggle="tooltip"]').tooltip();
            $('[data-bs-toggle="popover"]').popover(); 
        });
        
 
           //pur javascript
        // document.addEventListener("DOMContentLoaded", function(){
        //     var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        //     var tooltipList = tooltipTriggerList.map(function(element){
        //         return new bootstrap.Tooltip(element);
        //     });
        // });
    
        // document.addEventListener("DOMContentLoaded", function(){
        //     var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
        //     var popoverList = popoverTriggerList.map(function(element){
        //         return new bootstrap.Popover(element);
        //     });
        // });
       